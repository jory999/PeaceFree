# babyos

2015-09-22
[boot]      #1 boot from hard disk

2015-09-20
[ttf]       #10 support draw with ttf

2015-09-18
[mm]        #2 memory manage, no paging

2015-09-15
[mouse] 	#16 draw mouse and mouse move

2015-09-14
[mm] 		#17 get total memory

2015-09-14
[mouse] 	#15 get mouse position by interrupt

2015-09-13
[hd] 		#13 read hard disk by interrupt

2015-09-12
[interrupt] #6 8259a
[interrupt] #5 exceptions&interrupt
[timer] 	#11 8253/8254 & real time
[keyboard] 	#14 keyboard

2015-09-12
[encoding]	#9 utf8 -> gb2312;
[font]		#9 draw string with dot matrix font;

2015-09-10
[hd, bmp]	read harddist sects and draw bitmap

2015-09-08
[boot, load, video]code from csdn code, draw a line
