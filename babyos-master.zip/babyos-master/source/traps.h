/*
 * guzhoudiaoke@126.com 
 * 2015-09-12 15:26
 */

#ifndef _TRAPS_H_
#define _TRAPS_H_

void init_trap();

#endif
