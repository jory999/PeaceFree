/*
 * guzhoudiaoke126.com
 * 2015-09-12 00:28
 */

#ifndef _ENCODING_H_
#define _ENCODING_H_

#include "types.h"

const u8* utf8_to_gb2312(u8* utf8);
void utf8_to_unicode(u8 *utf8, u8* unicode);

#endif
